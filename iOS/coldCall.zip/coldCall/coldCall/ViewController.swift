//
//  ViewController.swift
//  coldCall
//
//  Created by Briggs McKnight on 4/3/17.
//  Copyright © 2017 Briggs McKnight. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nameLabel: UILabel!
    let nameBank = ["Briggs", "Bob", "Max", "Jim", "Billy", "Frank", "Clair", "Denise", "Hillary", "Mohammed", "Ryan", "Susie", "Tiffany", "Jessica", "William"]

    var currentName = 0
   
    @IBAction func coldCallButton(_ sender: UIButton) {
        currentName = Int(arc4random_uniform(14))
        updateUI()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }
    
    func updateUI() {
        nameLabel.text = nameBank[currentName]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }


}

