//
//  ViewController.swift
//  tipster
//
//  Created by Briggs McKnight on 4/5/17.
//  Copyright © 2017 Briggs McKnight. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var totalLabel: UILabel!
    @IBOutlet weak var groupSizeLabel: UILabel!
    @IBOutlet weak var tip1Label: UILabel!
    @IBOutlet weak var tip2Label: UILabel!
    @IBOutlet weak var tip3Label: UILabel!
    @IBOutlet weak var add1Label: UILabel!
    @IBOutlet weak var add2Label: UILabel!
    @IBOutlet weak var add3Label: UILabel!
    @IBOutlet weak var total1Label: UILabel!
    @IBOutlet weak var total2Label: UILabel!
    @IBOutlet weak var total3Label: UILabel!
    @IBOutlet weak var groupSlider: UISlider!
    @IBOutlet weak var tipSlider: UISlider!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    var deci = false
    var count = 0
    @IBAction func numberButtonPressed(_ sender: UIButton) {
        if count <= 2{
            if totalLabel.text == "0"{
                totalLabel.text = ""
            }
            if sender.tag == 10{
                deci = true
                if var total = totalLabel.text{
                    total += "."
                    totalLabel.text = total
                }
            }
            else if var total = totalLabel.text{
                total += String(sender.tag)
                totalLabel.text = total
            }
            updateUI()
            if deci {
                count += 1
            }
        } else {
            
        }
    }
    
    func updateUI(){
        
        let cost = Float(totalLabel.text!)
        let group = round(groupSlider.value)
        let tip = round(tipSlider.value)
        let add1Amount = round((cost! * (tip/100))*100)/100
        let add2Amount = round((cost! * ((tip + 5)/100))*100)/100
        let add3Amount = round((cost! * ((tip + 10)/100))*100)/100
        let total1 = (round(((cost! + add1Amount)/group)*100))/100
        let total2 = (round(((cost! + add2Amount)/group)*100))/100
        let total3 = (round(((cost! + add3Amount)/group)*100))/100
        add1Label.text = String(round((add1Amount/group)*100)/100)
        add2Label.text = String(round((add2Amount/group)*100)/100)
        add3Label.text = String(round((add3Amount/group)*100)/100)
        total1Label.text = String(total1)
        total2Label.text = String(total2)
        total3Label.text = String(total3)
        
    }
    

    @IBAction func tipSlider(_ sender: UISlider) {
        let selectedValue1 = Int(sender.value)
        let selectedValue2 = Int(sender.value)+5
        let selectedValue3 = Int(sender.value)+10
        
        tip1Label.text = String(stringInterpolationSegment: selectedValue1)+"%"
        tip2Label.text = String(stringInterpolationSegment: selectedValue2)+"%"
        tip3Label.text = String(stringInterpolationSegment: selectedValue3)+"%"
        
        updateUI()
    }

    @IBAction func groupSlider(_ sender: UISlider) {
        let selectedValue = Int(sender.value)
        
        groupSizeLabel.text = "Group Size: " + String(stringInterpolationSegment: selectedValue)
        
        updateUI()
    }
    @IBAction func clearButtonPressed(_ sender: UIButton) {
        totalLabel.text = "0"
        add1Label.text = "0.00"
        total1Label.text = "0.00"
        add2Label.text = "0.00"
        total2Label.text = "0.00"
        add3Label.text = "0.00"
        total3Label.text = "0.00"
        count = 0
        deci = false
    }
}

