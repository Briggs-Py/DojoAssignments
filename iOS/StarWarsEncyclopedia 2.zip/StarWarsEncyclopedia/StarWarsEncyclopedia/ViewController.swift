//
//  ViewController.swift
//  StarWarsEncyclopedia
//
//  Created by Briggs McKnight on 4/17/17.
//  Copyright © 2017 Briggs McKnight. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    var names = [String]()
    var films = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "http://swapi.co/api/people/")
        // create a URLSession to handle the request tasks
        let session = URLSession.shared
        // create a "data task" to make the request and run the completion handler
        let task = session.dataTask(with: url!, completionHandler: {
            // see: Swift closure expression syntax
            data, response, error in
            do {
                // try converting the JSON object to "Foundation Types" (NSDictionary, NSArray, NSString, etc.)
                if let jsonResult = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary {
                    if let results = jsonResult["results"] {

                        // coercing the results object as an NSArray and then storing that in resultsArray
                        if let resultsArray = results as? NSArray {
                            print(resultsArray)
                            for char in resultsArray{
                                
                                if let resultsDict = char as? NSDictionary {
                                    print(resultsDict["name"]!)
                                    self.names.append(resultsDict["name"]! as! String)
                                }
                            }
                        }
                    }
                }
                self.tableView.reloadData()
            } catch {
                print(error)
            }
        })
        task.resume()
        
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
        cell.textLabel?.text = names[indexPath.row]
        return cell
    }
    
}

