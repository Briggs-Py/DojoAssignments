//
//  AddItemTableViewController.swift
//  bucketList
//
//  Created by Briggs McKnight on 4/10/17.
//  Copyright © 2017 Briggs McKnight. All rights reserved.
//

import UIKit

class AddItemTableViewController: UITableViewController {
    
    var stringToEdit: String?
    var idxPath: Int?
    
    weak var cancelButtonDelegate: cancelButtonDelegate?
    weak var addItemDelegate: AddItemDelegate?
    weak var editItemDelegate: EditItemDelegate?
    
    @IBOutlet weak var itemTextView: UITextView!
    
    
    @IBAction func saveButtonPressed(_ sender: UIBarButtonItem) {
        if let input = self.itemTextView.text {
            if let editID = self.editItemDelegate {
                editID.editItem(item: input, idx: self.idxPath!)
            } else {
                self.addItemDelegate?.addItem(item: input)
            }
        }
    }
    
    @IBAction func cancelButtonPressed(_ sender: UIBarButtonItem) {
        if let input = self.itemTextView.text {
            if let editID = self.editItemDelegate {
                editID.editItem(item: input, idx: self.idxPath!)
            } else {
                self.addItemDelegate?.addItem(item: input)
            }
        }

    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        if let str = stringToEdit {
            itemTextView.text = str
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
