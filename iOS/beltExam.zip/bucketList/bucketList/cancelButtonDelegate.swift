//
//  cancelButtonDelegate.swift
//  bucketList
//
//  Created by Briggs McKnight on 4/11/17.
//  Copyright © 2017 Briggs McKnight. All rights reserved.
//

import UIKit

protocol cancelButtonDelegate: class {
    func cancelButtonPressed(by controller: AddItemTableViewController)
}
