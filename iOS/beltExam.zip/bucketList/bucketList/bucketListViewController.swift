//
//  ViewController.swift
//  bucketList
//
//  Created by Briggs McKnight on 4/10/17.
//  Copyright © 2017 Briggs McKnight. All rights reserved.
//

import UIKit
import CoreData

class bucketListViewController: UITableViewController, AddItemDelegate, cancelButtonDelegate, EditItemDelegate, UISearchResultsUpdating, UISearchBarDelegate {

    @IBOutlet weak var searchBar: UISearchBar!
    
    var searchController = UISearchController(searchResultsController: nil)
    var items = [Item]()
    var filteredTableData = [Item]()
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    func getAllItems(){
        let itemRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
        do {
            // get the results by executing the fetch request we made earlier
            let results = try managedObjectContext.fetch(itemRequest)
            // downcast the results as an array of AwesomeEntity objects
            items = results as! [Item]
            filteredTableData = results as! [Item]
            // print the details of each item
            for item in items {
                print("\(String(describing: item.name))")
            }
        } catch {
            // print the error if it is caught (Swift automatically saves the error in "error")
            print("\(error)")
        }
        
        tableView.reloadData()
    }
    
    
    @IBAction func addButtonPressed(_ sender: UIBarButtonItem) {
        performSegue(withIdentifier: "EditItemSegue", sender: sender)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        searchController.searchResultsUpdater = self
        searchController.hidesNavigationBarDuringPresentation = false
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.sizeToFit()
        self.tableView.tableHeaderView = searchController.searchBar
        getAllItems()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchController.isActive {
            return filteredTableData.count
        }else{
            return items.count
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListItemCell", for: indexPath) as! TaskTableViewCell
        if searchController.isActive {
            cell.model = filteredTableData[indexPath.row]
        } else {
            cell.model = items[indexPath.row]
        }
        return cell
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "EditItemSegue", sender: indexPath.row)
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        managedObjectContext.delete(items[indexPath.row])
        if managedObjectContext.hasChanges {
            do {
                try managedObjectContext.save()
                print("Success")
            } catch {
                print("\(error)")
            }
        }
        getAllItems()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let send = sender {
            if send is Int {
                let navC = segue.destination as! UINavigationController
                let vc = navC.topViewController as! AddItemTableViewController
                vc.cancelButtonDelegate = self
                vc.addItemDelegate = self
                vc.editItemDelegate = self
                
                if let send = sender {
                    vc.idxPath = send as? Int
                    vc.stringToEdit = self.items[vc.idxPath!].name
                }
                
            } else {
                let navC = segue.destination as! UINavigationController
                let vc = navC.topViewController as! AddItemTableViewController
                vc.cancelButtonDelegate = self
                vc.addItemDelegate = self
                
            }
        }
    }
    
    func cancelButtonPressed(by controller: AddItemTableViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    func addItem(item: String) {
        dismiss(animated: true, completion: nil)
        let i = NSEntityDescription.insertNewObject(forEntityName: "Item", into: managedObjectContext) as! Item
        i.name = item
        if managedObjectContext.hasChanges {
            do {
                try managedObjectContext.save()
                print("Success")
            } catch {
                print("\(error)")
            }
        }
        
        getAllItems()
        
    }
    
    func editItem(item: String, idx: Int) {
        dismiss(animated: true, completion: nil)
        items[idx].name = item
        tableView.reloadData()
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        
        getAllItems()
        
        self.tableView.reloadData()
    }

    
}

