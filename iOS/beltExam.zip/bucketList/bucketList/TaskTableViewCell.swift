//
//  TaskTableViewCell.swift
//  bucketList
//
//  Created by Briggs McKnight on 4/21/17.
//  Copyright © 2017 Briggs McKnight. All rights reserved.
//

import UIKit

class TaskTableViewCell: UITableViewCell {
    
    //Outlets
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    
    
    //Model
    
    private var _model: Item?
    
    var model: Item {
        
        set {
            _model = newValue
            doStuff()
        }
        
        get {
            return _model!
        }
    }
    
    func doStuff(){
        nameLabel.text = _model?.name
        dateLabel.text = Date().toString()
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

extension Date {
    func toString() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        return dateFormatter.string(from: self)
    }
}
