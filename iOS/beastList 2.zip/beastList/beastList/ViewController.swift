//
//  ViewController.swift
//  beastList
//
//  Created by Briggs McKnight on 4/6/17.
//  Copyright © 2017 Briggs McKnight. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    var myArray = ["Bobby", "Nick", "Rob", "Kate", "Jill", "Nate", "Ryan", "Allen", "Squall", "Leon", "Paul", "Michael"]

    @IBOutlet weak var taskTextField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func beastButtonPressed(_ sender: UIButton) {
        if let textItem = taskTextField.text{
            myArray.append(textItem)
        }
        tableView.reloadData()
        taskTextField.text = ""
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myArray.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
        cell.textLabel?.text = myArray[indexPath.row]
        cell.detailTextLabel?.text = String(Int(arc4random_uniform(90)+5))+" years old"
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myArray.remove(at: indexPath.row)
        tableView.reloadData()
    }

}
