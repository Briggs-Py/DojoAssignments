module.exports = function Route(app, server){

    var io = require('socket.io').listen(server);

    app.get('/', function(req, res) {
      res.render('index');
    })

    io.sockets.on('connection', function(socket) {

        socket.on("button_pressed", function(data){
            io.emit('updated_message', {response: data});
        })
        socket.on("reset_pressed", function(data){
            io.emit('reset_triggered', {response: data});
        })
    })

};
